from flask import Blueprint, render_template, request, session, redirect, url_for
from app.models import Product
from app import db

main = Blueprint('main', __name__)
@main.route('/admin/add-product', methods=['GET', 'POST'])
def admin_add_product():
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        description = request.form['description']
        image = request.form['image']

        new_product = Product(name=name, price=price, description=description, image=image)
        db.session.add(new_product)
        db.session.commit()
        return redirect(url_for('main.home'))  # or back to admin page

    return render_template('admin_add_product.html')
@main.route('/')
def home():
    products = Product.query.all()
    return render_template('home.html', products=products)

@main.route('/add-to-cart/<int:product_id>')
def add_to_cart(product_id):
    cart = session.get('cart', [])
    cart.append(product_id)
    session['cart'] = cart
    return redirect(url_for('main.home'))

@main.route('/cart')
def view_cart():
    cart = session.get('cart', [])
    products = Product.query.filter(Product.id.in_(cart)).all()
    total = sum([p.price for p in products])
    return render_template('cart.html', products=products, total=total)

@main.route('/checkout')
def checkout():
    return render_template('checkout.html')
